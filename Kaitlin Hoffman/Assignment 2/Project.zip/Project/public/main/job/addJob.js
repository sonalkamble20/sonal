document.addEventListener("DOMContentLoaded", function () {
  
  document.getElementById("post").addEventListener("submit", function (event) {
  event.preventDefault();

  // Get the input values
  const jobname = document.getElementById("jobname").value.trim();
  const description = document.getElementById("description").value.trim();

  const job = {
    jobname: jobname,
    description: description
  }
  // Log the data that will be sent to the backend
  console.log("Data being sent:", job);

  // Make the POST request to the server
  fetch('http://localhost:3000/user/job', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(job)
  })
  .then(response => response.json())
  .then(data => console.log('Success:', data))
  .catch(error => console.error('Error:', error));
  
})

});
