document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("login").addEventListener('submit', function(event) {
        event.preventDefault();

        const userName = document.getElementById("uname").value;
        const password = document.getElementById("password").value;

        const user = {
            username: userName,
            password: password
        };

        console.log("User logged in: ", user);  // Check the sent user object

        fetch('http://localhost:3000/user/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(user)
        })
        .then(response => response.json())
        .then(data => {
            if (data.message) {
                alert(data.message);  // Show error message
            } else {
                console.log("Login successful", data);
                localStorage.setItem("user", JSON.stringify(data));
                window.location.href = "/public/main/job/post.html";
            }
        })
        
        .catch(error => console.log("Error:", error));
    });
});
